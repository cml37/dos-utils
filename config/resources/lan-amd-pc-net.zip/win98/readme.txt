Readme.txt
===========	

The NETAMD.INF file is used for all Win98, WinME and Win2000  
operating systems. They all use the same PCNTPCI5.SYS file.

================================
version 4.30 fixes below problem from 4.29 driver

1) 1c_reset test failure of HCT 9.502 from W2000 Check build version.

================================
version 4.29 fixes below problem

1) Deserialization of nic miniport functions.
2) 802.1p support
3) User administrated network address
4) Bug fixes to those submitted by MS.
5) Fixed bug - transmit stalls under stress
6) Support for WMI (DMI attributes)
7) Support for fiber NIC


