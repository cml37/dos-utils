
README.TXT
==========
     AMD PCnet-Home Software
     NDIS 3 Driver Version 1.08.007
     NDIS 4 Driver Version 1.08.007
     NDIS 5 Driver Version 1.08.007
     Release Date March 9, 2000


PLATFORMS SUPPORTED BY DEVICE DRIVERS
=====================================
     Windows 95 (all versions)
     Windows 98 and above
     Windows 2000
     Windows NT 3.51 and above


WHAT'S NEW IN NDIS 5 driver version 1.08.007
=========================================================

    The following changes have been made to the NDIS 3, NDIS 4 
    and NDIS 5 drivers since the previosuly released driver versions 
    (v1.06) included with the PCnet-Home Software v2.0 Release.

    All of these changes were made for supporting the Win 98 SE and 
    Win 2000 operating system requirements and driver issues pertaining to
    those platforms.  Specifically, changes were required in the NDIS 5
    device driver.  However, the NDIS 4 and NDIS 3 drivers were
    required to be updated as well because these drivers share the 
    same source base with the NDIS 5 driver.

	1. Modified VendorString to be read from the
	   registry to ensure that INF string matches
	   the driver string (Microsoft requirement)

	2. Added write to BCR49 just before entering
	   D3 to ensure that the last active phy is the one
	   that asserts PME for wakeup. Required for
	   NDIS 2m_media test to pass with 10 base-T
	   media.

	3. Added code to start phy auto-negotiation before
	   entering D3.

	4. Added Phy reset when transitioning to D1.

	5. Added delay after phy reset in LanceSetInformation()
	   when transitioning from D1 to D3.
	   Moved Phy init routine prototypes to LANCESFT.H because
	   they are now also called from REQUEST.C

	6. Added code to reset phy when going from D3
	   to D1 only when SFEX (10 Mbit internal) phy is
	   selected.

