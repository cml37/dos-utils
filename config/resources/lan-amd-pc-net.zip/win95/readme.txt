Readme.txt
==========
   AMD PCnet Family Software
   NDIS4 Miniport driver for Windows 9x and Windows NT
   Version 4.09

Changes made for this release
=============================
1. Support for Unattended Windows NT installation added to the default
   OEMSETUP.INF file.
2. Added support for multiple switches for PermaNet Server Link Fault 
   Tolerance (LFT) feature.
3. OEMSETUP.INF file has been modified to fix a bug, appearing during 
   a fresh installation of Windows NT, which gave an error that the pcnet.exe 
   file is missing.
4. RC file has been changed so that the driver reports the correct version 
   information under both Windows NT and Windows 95. 