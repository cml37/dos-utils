Readme.txt
==========
     AMD PCnet-Family Software
     ODI driver for Netware DOS Workstations
     Release 4.03



What's new in this release
==========================
Fixed the Auto-negotiation part for Am79C976
Fixed a minor issue with the Novell performance test.




Date 12-06-95
==========================
There are three building debug functions defined in the DOS-ODI driver.
(1) Serial port debug: To enable it by setting the equate "SerialDebug"
		       in the pcntnw.asm to -1 and re-assemble it.

		 All the support functions are defined in Sdebug.inc.
		 By default the driver uses COM2, and the seeting is
		 115200 N 8 1. If you need to change the setting, change
		 the bx value before calling "SerialInit" routine in the
		 DriverInit procedure. The valid setting is documented in
		 the sdebug.inc If you need to use COM1 instead of COM2,
		 set the equate "COM1SEL" to -1 then re-assemble it.

	Function supported: ( All registers are preserved automatically )

		ComASCIIWord	macro integer
			Encoded Word data to 4 ASCII digits and send out
			through serial port.

		ComASCIIByte	macro char
			Encoded Byte data to 2 ASCII digits and send out
			through serial port.

		ComDebugWord	macro integer
			Seial out one word.

		ComDebugByte	macro char
			Seial out one byte.

(2) Screen debug: To enable it by setting the equate "ScreenDebug"
		  in the pcntnw.asm to -1 and re-assemble it.

		 All the support functions are defined in Scdebug.inc.
		 By default the driver defined the debug window at column
		 58 ~ 79, Row 21 ~ 23. If you need to change the window's
		 location, change the equates WIN_MIN_COL, WIN_MIN_ROW,
		 WIN_MAX_COL and WIN_MAX_ROW in the scdebug.inc
		 ( The upper left corner of the screen is Row 0 Column 0.
		   The lower right corner of the screen is Row 24 Column 79 )

	Function supported: ( All registers are preserved automatically )

		OutDebugChar	macro char
			Display ASCII character to monochrome and color
			screens.

		OutDebugByte	macro char
			Convert Byte to 2 ASCII digits and display it
			to screen.

		OutDebugWord	macro integer
			Convert Word to 4 ASCII digits and display it
			to screen.


(3) Dump Statistic Counters: To enable it by setting the equate
			     "DumpStatCounters"	in the pcntnw.asm to -1
			     and re-assemble it. Then add a keyword 
			     "DUMPDIAG" in the NET.CFG

		 The function is defined in Pcntnw.inc.	By default the
		 driver will display all the statistics counters on the
		 screen at Row 3 Column 58. The window's width is 22. The
		 length is now 21. If you need to change the window's
		 location, change the equates DIAGS_ROW and DIAGS_COL.

		 Currently, the driver will display the following internal
		 statistic counters whenever any of them updates its value.

			RxOverflow
			RxTooBigCount
			TxMiscCount
			RxMiscCount
			RxCheckSumError
			TxBabbling
			MissPacketErr
			MemoryErr
			TxBufferErr
			TxUnderFlowErr
			TxRetryErr
			TxLateCollision
			TxTimedOut
			RxIntError
			RxFrameErr
			RxBufferErr
			ExcessCollision
			ResetChipCnt
			No RCB Count

There are also some debug keywords defined in the DOS-ODI. 

!!!! Warning : These keywords are used to help the engineer to debug
	       the system only. Don't release these information to
	       the end user.

(1) DMAPLUS:
	Set DMAPLUS bit in the CSR4.

(2) DMTOFF:
	Disable Dead man Timer.

(3) MODE16:
	Force the driver running in 16 bit mode ( for PCNetPCI & PCNet-32 ).

(4) IEEEADDR:
	Choose particular NIC. If there are more than one NICs on the system.
	This keyword is very useful for those NICs in Plug-N-Play mode.
	Parameter: 6 bytes board's IEEE address.
	
(5) CSR80:
	Overwrite CSR80's value.

(6) ShareINT:
	Enable/Disable Shared Interrupt on PCNet-PCI.
	Parameters: OFF, ON. ( Default ON )

(7) CERTIFYTxtLen
	Disable general service routine interface (ie. NO DMI support,
	NO multi-board support for those Plug-N-Play NICs ).
