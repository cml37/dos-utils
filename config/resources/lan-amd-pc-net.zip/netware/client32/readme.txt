AMD PCnet 32bit A-ODI Driver v4.14 for NetWare DOS Client32. 
============================================================

For this driver use in NetWare DOS Client32, please install 
latest NetWare Client32, Version 4.71.


The following are the details of this driver :

AMD Binary signature verion number v4.14.000
PCNTNW.LAN	26,493 bytes	06-26-98	13:38


