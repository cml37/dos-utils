readme.txt
==========
     AMD PCnet-Family Software
     ODI AHSM driver for Netware 4.x, and 5.x
     Version 4.23


What's new in this release 4.23
===============================
* Increased the maximum receive buffer size from 1518 to 1536.


What's new in this release 4.22
===============================
* Support for PCnet-FAST-PRO device has been added to this driver. 
* This 32-bit ODI driver now supports the PCnet-FX Fiber Channel controller. 

If you are using NetWare 4.11 and 4.2, please have Support Pack 8a for 
NetWare 4.2/4.11 installed on your system, if you are using NetWare 5.0 
please install Support Pack 5 for NetWare 5, or if you are using NetWare 
5.1 please installed Support Pack 1 for NetWare 5.1. These Service Packs 
may be downloaded from Novell's website at www.novell.com.
