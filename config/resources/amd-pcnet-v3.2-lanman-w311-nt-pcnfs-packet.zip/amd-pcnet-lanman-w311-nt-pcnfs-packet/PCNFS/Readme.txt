This directory contains files:

pcntnd.dos - The NDIS 2.0.1 DOS driver
pcntnd.nif - NIF file for NDIS installation under PCNFS
protocol.ini - A sample protocol.ini file for NDIS driver

This directory is provided for the quickndis installation utility
from PCNFS. Please make a directory called "pcntnd" on your quickndis
floppy and copy the contents of this directory in the pcntnd directory
on the quickndis floppy. Run the PCNFS quickndis utility and choose the
PCNet family installation from the menu.
