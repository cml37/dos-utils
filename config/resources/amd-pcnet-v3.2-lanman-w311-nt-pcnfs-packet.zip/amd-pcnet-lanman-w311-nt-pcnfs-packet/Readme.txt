
		PCnet Software


		Version 3.2

		October 1996



The included are:

	AMINSTAL.BAT	AMInstall (Generic Installation utility)
	\LANSRVR	For IBM LAN Server
	\MSLANMAN.DOS	For Microsoft LAN Manager
	\MSLANMAN.OS2	For Microsoft LAN Manager
	\NOVELL		For Novell NetWare 
	\PCNFS		For SunSoft PC-NFS
	\PKTDRVR	For Packet driver
	\WFW31		For Microsoft Windows for Workgroup 3.1
	\WFW311		For Microsoft Windows for Workgroup 3.11
	\WINNT		For Microsoft Windows NT (3.1 and 3.5)

