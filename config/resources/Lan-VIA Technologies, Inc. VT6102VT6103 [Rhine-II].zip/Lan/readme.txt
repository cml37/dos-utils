**
**
**  VIA VT6102 Rhine II Fast Ethernet Adapter
**
**  Readme file for Drivers/Utilities
**
**  Release 2.6     Jun. 2002
**
**

This Diskette contains the configuration / diagnostic utilities and 
device drivers.


I. File Structure

A:.
|   DIAG.EXE
|   DIAG.TXT
|   README.TXT
|   RELEASE.DOC
|   FETNDIS.INF
|   FETND.DOS
|   FETND3.SYS
|   FETND4.SYS
|   FETND5A.SYS
|   FETND5B.SYS
|   FETODI.COM
|   FETNDI.DLL
|   NETVT.CAT
|   OEMSETUP.INF
|   NTUTIL.DLL
|   PCIENUM.SYS
|   WIN.TXT
|   WINNT.TXT
|   WINSETUP.EXE
|   WINSETUP.TXT
|
+---EEPROM
|       EEPROM.EXE
|       EEPROM.TXT
|       EEPROM.CFG
|       EEP6102.DOC
|
+---FREEBSD
|       FREEBSD.TAR
|       FREEBSD.TXT
|       
+---LANSVR40.DOS
|       FETND.DOS
|       LSDOS.TXT
|       OEMSETUP.INF
|       
+---LANTASTI
|       FETND.DOS
|       LANTASTI.TXT
|       PROTOCOL.INI
|       
+---LINUX
|       LINUX.TXT
|       VIALINUX.TAR
|       
+---MSLANMAN.DOS
|   \---DRIVERS
|       +---ETHERNET
|       |   +---FETND
|       |   |       FETND.DOS
|       |   |       LMDOS.TXT
|       |   |       PROTOCOL.INI
|       |   |       
|       |   \---VIAND
|       \---NIF
|               FETND.NIF
|               
+---NETWARE
|   +---CLIENT32
|   |       CNT32W95.TXT
|   |       CNT32DOS.TXT
|   |       FETNWSRV.LAN
|   |       FETNWSRV.INF
|   |       
|   +---DOSODI
|   |       DOSODI.TXT
|   |       FETODI.COM
|   |       FETODI.INS
|   |       NET.CFG
|   |       
|   +---SRVRODI.311
|   |       ETHERTSM.NLM
|   |       FETNWSRV.LAN
|   |       FETNWSRV.LDI
|   |       LSLENH.NLM
|   |       MONITOR.NLM
|   |       MSM31X.NLM
|   |       NBI31X.NLM
|   |       NW311.TXT
|   |       PATCHMAN.NLM
|   |       
|   +---SRVRODI.312
|   |       ETHERTSM.NLM
|   |       FETNWSRV.LAN
|   |       FETNWSRV.LDI
|   |       MSM31X.NLM
|   |       NBI31X.NLM
|   |       NW312.TXT
|   |       
|   \---SRVRODI.456
|           FETNWSRV.LAN
|           FETNWSRV.LDI
|           NW456.TXT
|         
|           
+---PCNFS
|       FETND.DOS
|       PCNFS.TXT
|       PROTOCOL.INI
|       
+---PKTDRVR
|       FETPKT.COM
|       PACKET.TXT
|       
+---PXE
|       PXE.NIC
|       PXE.TXT
|       RIS-NOTE.TXT
|       
+---SCO5
|       FETSCO5.A
|       FETSCO5.TXT
|       
+---UNATTEND
|   +---NT40
|   |     UNATDNT4.TXT
|   |     UNATTEND.TXT
|   |       
|   +---W2000
|   |     UNATDW2K.TXT
|   |     UNATTEND.TXT
|   |       
|   \---W9X
|   |     MSBATCH.INF
|   |     UNATDW9X.TXT
|   \---XP
|         UNATDWXP.TXT
|         UNATTEND.TXT
|
\---UNIXWARE
|       UNIXWARE.TXT
|       VTD.PKG
|       
\---WFW311
|       FETND.DOS
|       FETND3F.386
|       FETODI.COM
|       OEMSETUP.INF
|       WFW311.TXT
|       
\---WINSETUP
        NTSETUP.EXE
        NTSETUP.INF
        W2KSETUP.EXE
        W9XSETUP.EXE
        NTSIM.SYS


II. User Guide for Utilities

    README.TXT
         This file.
    DIAG.EXE
         Diagnostics program.
         
    Please refer to the text files (*.TXT) in each utility subdirectory.


III. User Guide for Drivers

    Please refer to the text files (*.TXT) in each driver subdirectory.
    For example, if you are installing Windows platform drivers, please 
    read the text file in \WIN.TXT for installation information.


IV. User Guide for Unattended Mode Installation

    Please refer to the text files (*.TXT) in \UNATTEND\ subdirectory.
    You could find the sample file in each subdirectory as well.

