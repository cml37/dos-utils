AMD PCnet 32bit A-ODI Driver v4.14 for NetWare 3.12 and 3.2 Server. 
=================================================================

For NetWare 3.12 Server, follow files should be installed before 
load this driver.
312PTD.EXE	Nov. 22, 1999 
ODI33G.EXE 	Mar. 30, 2000

For NetWare 3.2 Server, follow file should be installed before 
load this driver.
DRVSPC.EXE	Dec. 02, 1998

The following are the details of this driver :

AMD Binary signature verion number v4.14.000
PCNTNW.LAN	26,493 bytes	06-26-98	13:38


